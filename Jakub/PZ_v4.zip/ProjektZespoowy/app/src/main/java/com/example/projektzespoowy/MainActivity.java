package com.example.projektzespoowy;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projektzespoowy.databinding.ActivityMainBinding;

import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;


    Button listen, send, listDevices;
    ListView listView;
    TextView msg_box;
    TextView status;
    EditText writeMsg; //kąt obrotu

    BluetoothAdapter myBluetoothAdapter;
    Intent btEnablingIntent;
    // BroadcastReceiver receiver;

    int requestCodeForEnable;
    int btIsOn = 0;
    int searchIsClicked = 0;
    BluetoothDevice[] btArray;
    ArrayAdapter<String> adapter;


    static final int STATE_LISTENING = 1;
    static final int STATE_CONNECTING = 2;
    static final int STATE_CONNECTED = 3;
    static final int STATE_CONNECTION_FAILED = 4;
    static final int STATE_MESSAGE_RECEIVED = 5;

    int REQUEST_ENABLE_BLUETOOTH = 1;

    private static final String APP_NAME = "BTChat";
    private static final UUID MY_UUID = UUID.fromString("514a1018-ef13-11ec-8ea0-0242ac120002");


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);

        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        findViewByIdes();
        myBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        requestCodeForEnable = 1;
        bluetoothONMethod();

        exeButton();
    }

    private void exeButton() {
        listen.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    /*
                    String permission = "android.permission.BLUETOOTH_CONNECT";
                    int requestCode = 1;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        requestPermissions(new String[]{permission},requestCode);
                    }
                    */

                    Toast.makeText(getApplicationContext(), "BT connect permission ERROR", Toast.LENGTH_SHORT).show();
                    startActivityForResult(enableIntent, REQUEST_ENABLE_BLUETOOTH);
                    //return;
                }
                Toast.makeText(getApplicationContext(), "REEEEEE", Toast.LENGTH_SHORT).show();


                Set<BluetoothDevice> bt = myBluetoothAdapter.getBondedDevices();
                String[] strings = new String[bt.size()];
                int index = 0;

                if(bt.size() > 0)
                {
                    for (BluetoothDevice device:bt)
                    {
                        strings[index]= device.getName();
                        index++;
                    }
                    Toast.makeText(getApplicationContext(), "VVVVVVVVVVVVVVVV", Toast.LENGTH_SHORT).show();
                    ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1,strings);
                    listView.setAdapter(arrayAdapter);
                }
            }
        });
    }


    private void findViewByIdes() {
        listen = (Button) findViewById(R.id.listen);
        send = (Button) findViewById(R.id.send);
        listView = (ListView) findViewById(R.id.listview);
        msg_box = (TextView) findViewById(R.id.msg);
        status = (TextView) findViewById(R.id.status);
        writeMsg = (EditText) findViewById(R.id.katObrotu);
        listDevices = (Button) findViewById(R.id.listDevices);

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == requestCodeForEnable) {
            if (resultCode == RESULT_OK) {
                btIsOn = 1;
                Toast.makeText(getApplicationContext(), "Bluetooth włączone", Toast.LENGTH_SHORT).show();
            } else {
                if (resultCode == RESULT_CANCELED) {
                    Toast.makeText(getApplicationContext(), "Błąd uruchomienia bluetooth!", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void bluetoothONMethod() {
        if (myBluetoothAdapter == null) {
            Toast.makeText(getApplicationContext(), "Nie wykryto bluetooth!", Toast.LENGTH_LONG).show();
        } else {
            if (!myBluetoothAdapter.isEnabled()) {
                Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {

                    startActivityForResult(enableIntent, REQUEST_ENABLE_BLUETOOTH);
                    //return;
                }

            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}